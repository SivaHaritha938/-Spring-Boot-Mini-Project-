-- Sample data for testing
INSERT INTO students (first_name, last_name, email, date_of_birth, phone_number, address, enrollment_status, created_at, updated_at) VALUES
('John', 'Doe', 'john.doe@email.com', '2000-05-15', '555-0101', '123 Main St, Anytown, USA', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Jane', 'Smith', 'jane.smith@email.com', '1999-08-22', '555-0102', '456 Oak Ave, Somewhere, USA', 'ACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Bob', 'Johnson', 'bob.johnson@email.com', '2001-12-10', '555-0103', '789 Pine Rd, Elsewhere, USA', 'INACTIVE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Alice', 'Williams', 'alice.williams@email.com', '1998-03-07', '555-0104', '321 Elm St, Nowhere, USA', 'GRADUATED', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
('Charlie', 'Brown', 'charlie.brown@email.com', '2002-11-18', '555-0105', '654 Maple Dr, Anyplace, USA', 'SUSPENDED', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);