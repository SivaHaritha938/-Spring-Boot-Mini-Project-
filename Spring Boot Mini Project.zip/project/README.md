# Student Management Microservice REST API

A comprehensive Student Management system built with Java Spring Boot, providing RESTful APIs for managing student data in an educational institution.

## Features

- **CRUD Operations**: Create, Read, Update, and Delete students
- **Search & Filter**: Search students by name/email and filter by enrollment status
- **Pagination**: Support for paginated results with sorting
- **Validation**: Input validation with proper error handling
- **Exception Handling**: Global exception handling with meaningful error responses
- **Database Integration**: JPA/Hibernate with PostgreSQL support
- **Testing**: Unit tests for controllers and services

## Technology Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Data JPA**
- **Spring Web**
- **Spring Validation**
- **PostgreSQL** (Production)
- **H2 Database** (Development & Testing)
- **Maven** (Build Tool)
- **JUnit 5** (Testing)

## API Endpoints

### Students Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/students` | Get all students (paginated) |
| GET | `/api/v1/students/{id}` | Get student by ID |
| GET | `/api/v1/students/email/{email}` | Get student by email |
| POST | `/api/v1/students` | Create new student |
| PUT | `/api/v1/students/{id}` | Update existing student |
| DELETE | `/api/v1/students/{id}` | Delete student |
| GET | `/api/v1/students/status/{status}` | Get students by enrollment status |
| GET | `/api/v1/students/search?query={query}` | Search students |
| GET | `/api/v1/students/exists/email/{email}` | Check if email exists |

### Query Parameters

- `page`: Page number (default: 0)
- `size`: Page size (default: 10)
- `sortBy`: Sort field (default: id)
- `sortDir`: Sort direction (asc/desc, default: asc)

## Student Model

```json
{
  "id": 1,
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@email.com",
  "dateOfBirth": "2000-05-15",
  "phoneNumber": "555-0101",
  "address": "123 Main St, Anytown, USA",
  "enrollmentStatus": "ACTIVE",
  "createdAt": "2024-01-01T10:00:00",
  "updatedAt": "2024-01-01T10:00:00"
}
```

### Enrollment Status Options
- `ACTIVE`: Currently enrolled and active
- `INACTIVE`: Temporarily inactive
- `GRADUATED`: Successfully completed studies
- `SUSPENDED`: Temporarily suspended

## Running the Application

### Prerequisites
- Java 17 or higher
- Maven 3.6+
- PostgreSQL (for production)

### Development Mode
The application uses H2 in-memory database for development:

```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

### H2 Console
Access the H2 database console at: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:testdb`
- Username: `sa`
- Password: `password`

### Production Configuration
For production with PostgreSQL, update `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/studentdb
spring.datasource.username=your_username
spring.datasource.password=your_password
spring.jpa.hibernate.ddl-auto=validate
```

## Testing

Run the test suite:

```bash
mvn test
```

## Sample API Calls

### Create a Student
```bash
curl -X POST http://localhost:8080/api/v1/students \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john.doe@email.com",
    "dateOfBirth": "2000-05-15",
    "phoneNumber": "555-0101",
    "address": "123 Main St",
    "enrollmentStatus": "ACTIVE"
  }'
```

### Get All Students (Paginated)
```bash
curl "http://localhost:8080/api/v1/students?page=0&size=5&sortBy=firstName&sortDir=asc"
```

### Search Students
```bash
curl "http://localhost:8080/api/v1/students/search?query=john"
```

### Get Students by Status
```bash
curl "http://localhost:8080/api/v1/students/status/ACTIVE"
```

## Error Handling

The API provides structured error responses:

```json
{
  "status": 404,
  "message": "Student not found with id: 999",
  "timestamp": "2024-01-01T10:00:00"
}
```

For validation errors:

```json
{
  "status": 400,
  "message": "Validation failed",
  "timestamp": "2024-01-01T10:00:00",
  "errors": {
    "firstName": "First name is required",
    "email": "Email should be valid"
  }
}
```

## Project Structure

```
src/
├── main/
│   ├── java/com/example/studentmanagement/
│   │   ├── controller/          # REST Controllers
│   │   ├── service/            # Business Logic
│   │   ├── repository/         # Data Access Layer
│   │   ├── model/              # Entity Models
│   │   ├── exception/          # Exception Handling
│   │   └── StudentManagementApplication.java
│   └── resources/
│       ├── application.properties
│       └── data.sql            # Sample Data
└── test/                       # Unit Tests
```

This microservice demonstrates enterprise-level Java development with Spring Boot, following best practices for REST API design, error handling, and database integration.