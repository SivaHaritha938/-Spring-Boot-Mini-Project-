package com.example.studentmanagement.controller;

import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.service.StudentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(StudentController.class)
class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudentService studentService;

    @Autowired
    private ObjectMapper objectMapper;

    private Student testStudent;

    @BeforeEach
    void setUp() {
        testStudent = new Student(
                "John",
                "Doe",
                "john.doe@email.com",
                LocalDate.of(2000, 5, 15),
                "555-0101",
                "123 Main St",
                Student.EnrollmentStatus.ACTIVE
        );
        testStudent.setId(1L);
    }

    @Test
    void getAllStudents_ShouldReturnPageOfStudents() throws Exception {
        Page<Student> studentPage = new PageImpl<>(Arrays.asList(testStudent), PageRequest.of(0, 10), 1);
        when(studentService.getAllStudents(any())).thenReturn(studentPage);

        mockMvc.perform(get("/api/v1/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].firstName").value("John"))
                .andExpect(jsonPath("$.content[0].lastName").value("Doe"))
                .andExpect(jsonPath("$.content[0].email").value("john.doe@email.com"));
    }

    @Test
    void getStudentById_WhenExists_ShouldReturnStudent() throws Exception {
        when(studentService.getStudentById(1L)).thenReturn(Optional.of(testStudent));

        mockMvc.perform(get("/api/v1/students/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("John"))
                .andExpect(jsonPath("$.lastName").value("Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@email.com"));
    }

    @Test
    void getStudentById_WhenNotExists_ShouldReturnNotFound() throws Exception {
        when(studentService.getStudentById(anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/v1/students/999"))
                .andExpect(status().isNotFound());
    }

    @Test
    void createStudent_WithValidData_ShouldReturnCreatedStudent() throws Exception {
        when(studentService.createStudent(any(Student.class))).thenReturn(testStudent);

        mockMvc.perform(post("/api/v1/students")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testStudent)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.firstName").value("John"))
                .andExpect(jsonPath("$.lastName").value("Doe"))
                .andExpect(jsonPath("$.email").value("john.doe@email.com"));
    }

    @Test
    void updateStudent_WithValidData_ShouldReturnUpdatedStudent() throws Exception {
        Student updatedStudent = new Student(
                "Jane",
                "Doe",
                "jane.doe@email.com",
                LocalDate.of(2000, 5, 15),
                "555-0101",
                "123 Main St",
                Student.EnrollmentStatus.ACTIVE
        );
        updatedStudent.setId(1L);

        when(studentService.updateStudent(anyLong(), any(Student.class))).thenReturn(updatedStudent);

        mockMvc.perform(put("/api/v1/students/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedStudent)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("Jane"))
                .andExpect(jsonPath("$.email").value("jane.doe@email.com"));
    }

    @Test
    void deleteStudent_ShouldReturnNoContent() throws Exception {
        mockMvc.perform(delete("/api/v1/students/1"))
                .andExpect(status().isNoContent());
    }
}