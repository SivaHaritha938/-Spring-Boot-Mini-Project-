package com.example.studentmanagement.service;

import com.example.studentmanagement.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface StudentService {
    
    List<Student> getAllStudents();
    
    Page<Student> getAllStudents(Pageable pageable);
    
    Optional<Student> getStudentById(Long id);
    
    Optional<Student> getStudentByEmail(String email);
    
    Student createStudent(Student student);
    
    Student updateStudent(Long id, Student studentDetails);
    
    void deleteStudent(Long id);
    
    List<Student> getStudentsByEnrollmentStatus(Student.EnrollmentStatus status);
    
    Page<Student> searchStudents(String searchTerm, Pageable pageable);
    
    Page<Student> getStudentsByEnrollmentStatus(Student.EnrollmentStatus status, Pageable pageable);
    
    boolean existsByEmail(String email);
}